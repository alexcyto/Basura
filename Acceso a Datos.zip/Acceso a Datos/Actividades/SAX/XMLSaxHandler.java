package SAX;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/*
-Crea un programa SAX que llegeixi un XML videojocs.xml que tinguis ja creat.
-Tambe ha de llegir els atributs si es que te alguns.
-Si el programa detecta un element amb el text "Nada" imprimir per pantalla un miassatge de error amb system.err.println("Nodo vacio").
-Crea un metode que mostri una llista dels titols dels videojocs.
-Crea un metode que introdueixis per parametre 2 anys(per exemple 2010,2020) i mostri tots els jocs que shan creat dins daquell periode.
-Crea un metode que rebi per parametre un any i mostri el joc de lany indicat.
 */

public class XMLSaxHandler extends DefaultHandler {
	
	//Declaro arrays y variables
	String arr1[];
	String arr2[];
	String any[];
	String titulo = "";
	String anio= "";
	int e = 0;
	int x = 0;
	int a = 0;
		
	public void startDocument() throws SAXException{
		System.out.println("-------------------------------------------------");
		System.out.println("Start of the document");
		System.out.println("-------------------------------------------------");
		
		//Inicializo arrays y variables
		arr1 = new String[5];
		arr2 = new String[5];
		any = new String[3];
	}
	
	//Estos métodos recorren los arrays y muestran su contenido (titulos de juegos)
	public void mostrarTitulos() {
		for(int i=0; arr1.length > i;i++) {
			System.out.println(arr1[i]);
		}
	}
	
	public void mostrarjuegoanio() {
		for(int i=0; arr1.length > i;i++) {
			System.out.println(arr2[i]);
		}
	}

	
	public void endDocument() throws SAXException{
		//muestro todos los metodos al final del documento
		System.out.println("-------------------------------------------------");
		System.out.println("Titulos de juegos");
		System.out.println("-------------------------------------------------");
		mostrarTitulos();		
		System.out.println("-------------------------------------------------");
		
		System.out.println("Juego del año");
		System.out.println("-------------------------------------------------");
		mostrarjuegoanio();

		System.out.println("-------------------------------------------------");
		System.out.println("Juegos entre 2 años");
		System.out.println("-------------------------------------------------");
		titulosDosAnios(2000, 2020);
		
		
		System.out.println("-------------------------------------------------");
		System.out.println("End of the document document:");
		System.out.println("-------------------------------------------------");
	}


	
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException{
		//Igualo las variables titulo y año a el las etiquetas del xml como por ejemplo <titulo>
		this.titulo = qName;
		this.anio = qName;
		if(attributes.getValue(0)!=null) {
			System.out.println("Start Element name:"+ qName + " Attributo: " + attributes.getValue(0));
			
            //Recorre el array y busca si tiene atributos y lo guarda dentro de el

			for(int i=0;i<attributes.getLength();i++){
	            any[a] = attributes.getValue(i);
	            a++;
			}
		}else {
			System.out.println("Start Element name:"+qName);
		}
		
	}
	
	public void endElement(String uri, String localName, String qName) throws SAXException{
		System.out.println("End of element:"+qName);
	}
	
	public void characters(char ch[],int start,int length) throws SAXException{
		String s = new String(ch,start,length);
		//Si encuentra un elemento con la palabra "Nada", saldrá un mensaje de error poniendo en rojo "Nodo Vacío"
		if(s.equals("Nada")) {
			System.err.println("Nodo vacio");
		}else {			
			System.out.println("Characters :"+ new String(ch,start,length));
		}
		//Meto los titulos de los juegos en un array para mostrarlos
		if(this.titulo.equals("titulo")) {
			arr1[e] = s;
			e++;
			this.titulo = "";
		}
		//Lo mismo que lo de arriba pero solo pasará si un juego tiene la etiqueta <gameaward>
		if(this.anio.equals("gameaward")) {
			arr2[x] = s;
			x++;
			this.anio = s;
		}
	}	
	
	public void titulosDosAnios(int anio1, int anio2) {
		 //Compara 2 numeros con los numeros del a array y muestra los titulos si estan entre esos años
        for(int i=0;i<any.length;i++){
            int ANY = Integer.parseInt(any[i]);
            if(ANY>=anio1 && ANY<=anio2){
                System.out.println(arr1[i]);
            }
	}
	
	}
}
	
	
